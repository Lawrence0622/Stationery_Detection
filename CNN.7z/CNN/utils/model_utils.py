import torch
import os
from typing import Dict, Any, Optional

def save_checkpoint(state: Dict[str, Any], is_best: bool, 
                   save_dir: str, filename: str = 'checkpoint.pth'):
    """保存檢查點"""
    os.makedirs(save_dir, exist_ok=True)
    checkpoint_file = os.path.join(save_dir, filename)
    torch.save(state, checkpoint_file)
    
    if is_best:
        best_file = os.path.join(save_dir, 'model_best.pth')
        torch.save(state, best_file)

def load_checkpoint(checkpoint_path: str, model: torch.nn.Module, 
                   optimizer: Optional[torch.optim.Optimizer] = None, 
                   scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None) -> Dict[str, Any]:
    """加載檢查點"""
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"找不到檢查點文件：{checkpoint_path}")
    
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    if optimizer is not None and 'optimizer_state_dict' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    if scheduler is not None and 'scheduler_state_dict' in checkpoint:
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
    
    return checkpoint

def get_model_info(model: torch.nn.Module) -> Dict[str, Any]:
    """獲取模型信息"""
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    return {
        'total_parameters': total_params,
        'trainable_parameters': trainable_params,
        'model_structure': str(model)
    }

def initialize_weights(model: torch.nn.Module):
    """初始化模型權重"""
    for m in model.modules():
        if isinstance(m, (torch.nn.Conv2d, torch.nn.Linear)):
            torch.nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            if m.bias is not None:
                torch.nn.init.constant_(m.bias, 0)
        elif isinstance(m, torch.nn.BatchNorm2d):
            torch.nn.init.constant_(m.weight, 1)
            torch.nn.init.constant_(m.bias, 0)