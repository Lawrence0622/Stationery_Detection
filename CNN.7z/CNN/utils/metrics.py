import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import json
import os
from datetime import datetime, timedelta
import time
from typing import Dict, Any

class MetricsTracker:
    """訓練指標追蹤器"""
    def __init__(self, save_dir: str, config: Dict = None):
        self.save_dir = save_dir
        self.config = config or {}
        
        # 訓練指標
        self.train_losses = []
        self.val_losses = []
        self.train_accs = []
        self.val_accs = []
        self.learning_rates = []
        
        # 最佳指標
        self.best_val_acc = 0
        self.best_epoch = 0
        
        # 訓練時間追蹤
        self.start_time = time.time()
        self.epoch_times = []
        
        # 確保保存目錄存在
        os.makedirs(save_dir, exist_ok=True)
        os.makedirs(os.path.join(save_dir, 'checkpoints'), exist_ok=True)
    
    def update(self, train_metrics: Dict, val_metrics: Dict, 
               current_lr: float = None, epoch_time: float = None) -> bool:
        """更新指標"""
        # 更新基本指標
        self.train_losses.append(train_metrics['loss'])
        self.val_losses.append(val_metrics['loss'])
        self.train_accs.append(train_metrics['accuracy'])
        self.val_accs.append(val_metrics['accuracy'])
        
        # 更新學習率和時間
        if current_lr is not None:
            self.learning_rates.append(current_lr)
        if epoch_time is not None:
            self.epoch_times.append(epoch_time)
        
        # 檢查是否是最佳模型
        is_best = val_metrics['accuracy'] > self.best_val_acc
        if is_best:
            self.best_val_acc = val_metrics['accuracy']
            self.best_epoch = len(self.train_losses) - 1
        
        return is_best
    
    def plot_metrics(self):
        """繪製訓練指標圖表"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
        
        # 損失曲線
        ax1.plot(self.train_losses, label='Train Loss')
        ax1.plot(self.val_losses, label='Validation Loss')
        ax1.set_title('Loss Curves')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        ax1.legend()
        ax1.grid(True)
        
        # 準確率曲線
        ax2.plot(self.train_accs, label='Train Accuracy')
        ax2.plot(self.val_accs, label='Validation Accuracy')
        ax2.set_title('Accuracy Curves')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy (%)')
        ax2.legend()
        ax2.grid(True)
        
        # 學習率變化
        if self.learning_rates:
            ax3.plot(self.learning_rates, label='Learning Rate')
            ax3.set_title('Learning Rate Changes')
            ax3.set_xlabel('Epoch')
            ax3.set_ylabel('Learning Rate')
            ax3.set_yscale('log')
            ax3.legend()
            ax3.grid(True)
        
        # Epoch 時間
        if self.epoch_times:
            ax4.plot(self.epoch_times, label='Epoch Time')
            ax4.set_title('Training Time per Epoch')
            ax4.set_xlabel('Epoch')
            ax4.set_ylabel('Time (seconds)')
            ax4.legend()
            ax4.grid(True)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.save_dir, 'training_metrics.png'))
        plt.close()

    def plot_confusion_matrix(self, model, val_loader, device):
        """生成並保存混淆矩陣"""
        model.eval()
        all_preds = []
        all_labels = []
        
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs = inputs.to(device)
                outputs = model(inputs)
                _, preds = outputs.max(1)
                
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.numpy())
        
        # 計算混淆矩陣
        cm = confusion_matrix(all_labels, all_preds)
        
        # 獲取類別名稱
        class_names = val_loader.dataset.classes
        
        # 繪製混淆矩陣
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                    xticklabels=class_names,
                    yticklabels=class_names)
        plt.title('Confusion Matrix')
        plt.xlabel('Predicted')
        plt.ylabel('True')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.save_dir, 'confusion_matrix.png'))
        plt.close()
        
        # 計算每個類別的準確率
        class_accuracy = cm.diagonal() / cm.sum(axis=1)
        
        # 生成評估報告
        report = ["Confusion Matrix Analysis", "=" * 30, ""]
        report.append("Per-class Accuracy:")
        for i, acc in enumerate(class_accuracy):
            report.append(f"{class_names[i]}: {acc:.2%}")
        
        report.append("\nConfusion Matrix:")
        report.append("\nTrue \\ Pred\t" + "\t".join(class_names))
        for i, row in enumerate(cm):
            report.append(f"{class_names[i]}\t" + "\t".join(map(str, row)))
        
        with open(os.path.join(self.save_dir, 'confusion_matrix_report.txt'), 'w') as f:
            f.write('\n'.join(report))
        
        return cm, class_accuracy
    
    def save_metrics(self, config=None):
        """保存訓練指標到JSON文件"""
        total_time = time.time() - self.start_time
        
        # 如果沒有提供config，使用空字典
        if config is None:
            config = {}
        
        metrics_dict = {
            'training_config': {
                'batch_size': config.get('batch_size', None),
                'learning_rate': config.get('lr', None),
                'weight_decay': config.get('weight_decay', None),
                'epochs': len(self.train_losses),
                'early_stopping_patience': config.get('patience', None)
            },
            'training_metrics': {
                'train_losses': self.train_losses,
                'val_losses': self.val_losses,
                'train_accuracies': self.train_accs,
                'val_accuracies': self.val_accs,
                'learning_rates': self.learning_rates,
                'epoch_times': self.epoch_times,
                'best_val_accuracy': float(self.best_val_acc),
                'best_epoch': self.best_epoch,
                'total_training_time': str(timedelta(seconds=int(total_time))),
                'average_epoch_time': float(np.mean(self.epoch_times)) if self.epoch_times else 0
            }
        }
        
        # 保存到文件
        metrics_file = os.path.join(self.save_dir, 'training_metrics.json')
        with open(metrics_file, 'w') as f:
            json.dump(metrics_dict, f, indent=4)
        
        # 生成訓練報告
        self._generate_training_report(metrics_dict)
    
    def _generate_training_report(self, metrics: Dict):
        """生成訓練報告"""
        report = [
            "Training Report",
            "===============",
            f"Generated at: {datetime.now():%Y-%m-%d %H:%M:%S}",
            "",
            "Training Configuration",
            "---------------------",
            f"Batch Size: {metrics['training_config']['batch_size']}",
            f"Initial Learning Rate: {metrics['training_config']['learning_rate']}",
            f"Weight Decay: {metrics['training_config']['weight_decay']}",
            f"Total Epochs: {metrics['training_config']['epochs']}",
            "",
            "Training Results",
            "---------------",
            f"Best Validation Accuracy: {metrics['training_metrics']['best_val_accuracy']:.2f}%",
            f"Best Epoch: {metrics['training_metrics']['best_epoch']}",
            f"Total Training Time: {metrics['training_metrics']['total_training_time']}",
            f"Average Epoch Time: {metrics['training_metrics']['average_epoch_time']:.2f} seconds",
            "",
            "Final Metrics",
            "-------------",
            f"Final Training Loss: {metrics['training_metrics']['train_losses'][-1]:.4f}",
            f"Final Validation Loss: {metrics['training_metrics']['val_losses'][-1]:.4f}",
            f"Final Training Accuracy: {metrics['training_metrics']['train_accuracies'][-1]:.2f}%",
            f"Final Validation Accuracy: {metrics['training_metrics']['val_accuracies'][-1]:.2f}%"
        ]
        
        # 保存報告
        report_file = os.path.join(self.save_dir, 'training_report.txt')
        with open(report_file, 'w') as f:
            f.write('\n'.join(report))

def compute_metrics(outputs: torch.Tensor, targets: torch.Tensor, 
                   loss: torch.Tensor = None) -> Dict[str, float]:
    """計算訓練指標"""
    with torch.no_grad():
        # 計算準確率
        _, predicted = outputs.max(1)
        correct = predicted.eq(targets).sum().item()
        total = targets.size(0)
        accuracy = 100. * correct / total
        
        metrics = {
            'accuracy': accuracy
        }
        
        if loss is not None:
            metrics['loss'] = loss.item()
        
        return metrics