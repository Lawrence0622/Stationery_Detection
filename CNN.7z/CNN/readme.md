# 圖像分類專案

這是一個使用 PyTorch 實現的圖像分類專案，具有完整的訓練流程和模組化結構。

## 專案結構

```
final_project/
├── configs/
│   └── default_config.py    # 配置文件，包含模型、訓練等相關配置
├── preprocessing_data/
│   ├── img_composition.py   # 資料集樣本合成
│   ├── img_enhencement.py   # 資料集樣本增強
│   ├── img_png_to_jpg.py    # 照片格式轉換
│   ├── img_rename.py        # 資料集重新命名
│   ├── img_resize_output.py # 圖片尺寸重設並輸出到真實資料集中
│   └── readme.md            # 詳細解釋 
├── datasets/
│   ├── dataset.py           # 數據集類定義和數據加載器
│   ├── train/               # 訓練集目錄
│   └── val/                 # 驗證集目錄
├── models/
│   └── model_architecture.py # 模型架構定義
├── utils/
│   ├── logger.py            # 日誌記錄工具
│   ├── metrics.py           # 指標追蹤和計算
│   └── model_utils.py       # 模型相關工具函數
├── results/                 # 訓練結果保存目錄
│   └── experiment_timestamp/
│       ├── checkpoints/     # 模型檢查點
│       ├── training_metrics.png    # 訓練曲線圖
│       ├── training_metrics.json   # 訓練指標數據
│       └── training.log     # 訓練日誌
└── main.py                  # 主訓練腳本
```

## 主要模組功能

### 1. configs/default_config.py
- 定義所有配置參數
- 包含模型結構、訓練參數、數據增強設置等

### 2. datasets/dataset.py
- CustomImageDataset：自定義數據集類
- 實現數據加載和預處理
- 提供數據增強功能

### 3. models/model_architecture.py
- 定義模型架構
- 包含 CNN 模型實現
- 提供模型創建函數

### 4. utils/
#### logger.py
- 訓練日誌記錄
- 控制台和文件輸出

#### metrics.py
- 追蹤訓練指標
- 生成訓練曲線圖
- 保存訓練數據

#### model_utils.py
- 模型權重初始化
- 檢查點保存和加載
- 其他模型相關工具函數

### 5. main.py
- 主訓練腳本
- 整合所有組件
- 實現完整訓練流程

## 使用方法

### 1. 環境配置
```bash
pip install torch torchvision tqdm matplotlib
```

### 2. 數據準備
- 將原始圖像數據放在適當的目錄中
- 確保數據已按類別分類
- 目錄結構應如下：
  ```
  datasets/
  ├── train/
  │   ├── class1/
  │   ├── class2/
  │   └── ...
  └── val/
      ├── class1/
      ├── class2/
      └── ...
  ```

### 3. 開始訓練
```bash
python main.py --batch_size 32 --epochs 100 --lr 0.001 --num_workers 2
```

主要參數說明：
- `--batch_size`：批次大小（默認：32）
- `--epochs`：訓練輪數（默認：100）
- `--lr`：學習率（默認：0.001）
- `--num_workers`：數據加載線程數（Windows建議：2）
- `--device`：使用設備（'cuda' 或 'cpu'）
- `--patience`：早停耐心值（默認：15）

### 4. 訓練輸出
訓練過程中會生成：
- 模型檢查點（最佳模型和最新模型）
- 訓練指標圖表
- 詳細的訓練日誌
- JSON格式的訓練數據

### 5. 查看結果
訓練結果保存在 `results/experiment_timestamp/` 目錄下：
- `checkpoints/`：保存模型檢查點
- `training_metrics.png`：訓練曲線圖
- `training_metrics.json`：詳細訓練數據
- `training.log`：訓練日誌

## 注意事項

1. Windows系統建議：
   - 將 `num_workers` 設置為 2 或更小
   - 使用較小的 batch_size 以防止內存不足

2. CUDA顯卡：
   - 確保已安裝 CUDA 相容的 PyTorch 版本
   - 可用 `--device cuda` 啟用 GPU 訓練

3. 早停機制：
   - 當驗證集準確率不再提升時自動停止訓練
   - 可通過 `--patience` 參數調整耐心值

4. 模型保存：
   - 自動保存最佳模型和最新模型
   - 可在訓練中斷後繼續訓練

## 常見問題解決

1. 內存不足：
   - 減小 batch_size
   - 減少 num_workers
   - 使用較小的圖像尺寸

2. 訓練速度慢：
   - 確認是否使用 GPU
   - 增加 batch_size
   - 調整 num_workers

3. 模型效果不佳：
   - 調整學習率
   - 增加訓練輪數
   - 修改模型架構
   - 添加數據增強
