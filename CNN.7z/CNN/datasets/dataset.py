import os
import torch
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
from PIL import Image
from tqdm import tqdm

def calculate_mean_std(data_dir):
    """計算數據集的平均值和標準差"""
    print(f"正在計算數據集統計值...")
    print(f"處理目錄: {data_dir}")
    
    # 收集所有圖片路徑
    all_image_paths = []
    for folder in os.listdir(data_dir):
        folder_path = os.path.join(data_dir, folder)
        if os.path.isdir(folder_path):
            for img_name in os.listdir(folder_path):
                if img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
                    img_path = os.path.join(folder_path, img_name)
                    all_image_paths.append(img_path)
    
    print(f"找到 {len(all_image_paths)} 張圖片")
    
    # 創建基本轉換
    transform = transforms.Compose([
        transforms.ToTensor()
    ])
    
    # 計算平均值
    mean = torch.zeros(3)
    for img_path in tqdm(all_image_paths, desc="計算平均值"):
        try:
            img = Image.open(img_path).convert('RGB')
            img_tensor = transform(img)
            mean += img_tensor.mean([1, 2])
        except Exception as e:
            print(f"處理圖片時出錯 {img_path}: {str(e)}")
            continue
    
    mean = mean / len(all_image_paths)
    
    # 計算標準差
    std = torch.zeros(3)
    for img_path in tqdm(all_image_paths, desc="計算標準差"):
        try:
            img = Image.open(img_path).convert('RGB')
            img_tensor = transform(img)
            std += ((img_tensor - mean.view(3, 1, 1)) ** 2).mean([1, 2])
        except Exception as e:
            print(f"處理圖片時出錯 {img_path}: {str(e)}")
            continue
    
    std = torch.sqrt(std / len(all_image_paths))
    
    return mean.tolist(), std.tolist()

def get_transform(mean, std, is_training=True):
    """獲取數據轉換"""
    if is_training:
        return transforms.Compose([
            transforms.Resize((224, 224)),  # 直接调整到目标大小
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std)
        ])
    else:
        return transforms.Compose([
            transforms.Resize((224, 224)),  # 直接调整到目标大小
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std)
        ])

def get_dataloaders(data_dir, batch_size, num_workers=2):
    """獲取數據加載器
    
    Args:
        data_dir: 數據目錄路徑
        batch_size: 批次大小
        num_workers: 數據加載的工作線程數
    
    Returns:
        train_loader, val_loader: 訓練和驗證數據加載器
    """
    # 數據轉換
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])
    
    # 載入訓練集和驗證集
    train_dataset = datasets.ImageFolder(
        os.path.join(data_dir, 'train'),
        transform=transform
    )
    
    val_dataset = datasets.ImageFolder(
        os.path.join(data_dir, 'val'),
        transform=transform
    )
    
    # 創建數據加載器，在訓練集加入 shuffle=True
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,  # 啟用 shuffling
        num_workers=num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,  # 驗證集不需要打亂
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader
