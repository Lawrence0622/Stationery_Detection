import os
import shutil
from torchvision import transforms
from PIL import Image
import random
import numpy as np
import torch

def get_random_transform():
    """
    隨機返回一個轉換方法
    """
    transforms_list = [
        transforms.Compose([transforms.RandomHorizontalFlip(p=1.0)]),
        transforms.Compose([transforms.RandomRotation(30)]),
        transforms.Compose([
            transforms.RandomAffine(degrees=0, translate=(0.2, 0.2))
        ]),
        transforms.Compose([
            transforms.RandomAffine(degrees=0, scale=(0.8, 1.2))
        ]),
        transforms.Compose([
            transforms.RandomAffine(degrees=0, shear=15)
        ]),
        transforms.Compose([
            transforms.ColorJitter(
                brightness=0.3,
                contrast=0.3,
                saturation=0.3,
                hue=0.2
            )
        ]),
        transforms.Compose([transforms.GaussianBlur(kernel_size=3)]),
        transforms.Compose([transforms.RandomAutocontrast(p=1.0)])
    ]
    return random.choice(transforms_list)

def augment_folder(input_folder, output_folder, target_count=400):
    """
    對輸入資料夾中的圖片進行數據增強，通過隨機抽取和隨機轉換達到目標數量
    如果輸入樣本超過目標數量，則隨機選擇目標數量的樣本
    """
    # 檢查 GPU 是否可用
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用設備: {device}")

    # 如果輸出資料夾存在，先清空它
    if os.path.exists(output_folder):
        shutil.rmtree(output_folder)
    os.makedirs(output_folder)
    
    # 獲取所有圖片文件
    image_files = [f for f in os.listdir(input_folder) 
                  if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    original_count = len(image_files)
    
    print(f"開始處理資料夾: {os.path.basename(input_folder)}")
    print(f"原始圖片數量: {original_count}")
    
    # 如果原始數量超過目標數量，進行降採樣
    if original_count > target_count:
        print(f"原始數量({original_count})超過目標數量({target_count})，進行隨機抽樣")
        selected_files = random.sample(image_files, target_count)
        
        # 複製選中的圖片
        for img_file in selected_files:
            src_path = os.path.join(input_folder, img_file)
            dst_path = os.path.join(output_folder, img_file)
            shutil.copy2(src_path, dst_path)
            print(f"已複製抽樣圖片: {img_file}")
    
    # 如果原始數量小於目標數量，進行增強
    elif original_count < target_count:
        # 首先複製所有原始圖片
        for img_file in image_files:
            src_path = os.path.join(input_folder, img_file)
            dst_path = os.path.join(output_folder, img_file)
            shutil.copy2(src_path, dst_path)
            print(f"已複製原始圖片: {img_file}")
        
        # 計算需要增強的數量
        remaining = target_count - original_count
        aug_count = 0
        
        print(f"需要增強 {remaining} 張圖片")
        
        # 創建轉換器
        to_tensor = transforms.ToTensor()
        to_pil = transforms.ToPILImage()
        
        while aug_count < remaining:
            try:
                # 隨機選擇一張原始圖片
                img_file = random.choice(image_files)
                img_path = os.path.join(input_folder, img_file)
                img = Image.open(img_path)
                
                # 如果圖片不是RGB模式，轉換為RGB
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # 轉換為tensor並移至GPU
                img_tensor = to_tensor(img).to(device)
                img_tensor = img_tensor.unsqueeze(0)  # 添加 batch 維度
                
                # 獲取隨機轉換方法
                transform = get_random_transform()
                
                # 應用轉換
                with torch.no_grad():  # 不計算梯度，節省記憶體
                    aug_tensor = transform(img_tensor)
                
                # 將結果移回CPU並轉換為PIL圖片
                aug_tensor = aug_tensor.cpu().squeeze(0)
                aug_img = to_pil(aug_tensor)
                
                # 生成新的文件名
                name, ext = os.path.splitext(img_file)
                new_name = f"{name}_aug_{aug_count+1}{ext}"
                
                # 保存增強後的圖片
                save_path = os.path.join(output_folder, new_name)
                aug_img.save(save_path, quality=95)
                
                print(f"已處理 {img_file} 的增強版本 {aug_count+1}/{remaining}")
                aug_count += 1
                
                # 每處理100張圖片清理一次GPU緩存
                if aug_count % 100 == 0:
                    torch.cuda.empty_cache()
                
            except Exception as e:
                print(f"處理圖片時發生錯誤: {str(e)}")
                continue
    
    # 如果原始數量等於目標數量，直接複製
    else:
        for img_file in image_files:
            src_path = os.path.join(input_folder, img_file)
            dst_path = os.path.join(output_folder, img_file)
            shutil.copy2(src_path, dst_path)
            print(f"已複製原始圖片: {img_file}")
    
    final_count = len([f for f in os.listdir(output_folder) 
                      if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
    print(f"\n處理完成！")
    print(f"原始圖片數量: {original_count}")
    print(f"最終圖片數量: {final_count}")
    print("=" * 50)

# 使用示例
if __name__ == "__main__":
    # 設定隨機種子以確保結果可重現
    # torch.manual_seed(42)
    # random.seed(42)
    
    # 基本路徑
    base_input_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\composition_images_jpg"
    base_output_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\enhencement_images_jpg"
    
    # 類別列表
    classes = ['eraser', 'pen', 'glue', 'binder_clip', 'stapler']
    
    print("開始處理所有類別...")
    print("=" * 50)
    
    # 對每個類別進行處理
    for class_name in classes:
        input_folder = os.path.join(base_input_folder, class_name)
        output_folder = os.path.join(base_output_folder, class_name)
        
        print(f"\n處理類別: {class_name}")
        augment_folder(input_folder, output_folder, target_count=100)
    
    print("\n所有類別處理完成！")