import os

path = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\datasets\enhencement_images_png\stapler"
files = os.listdir(path)
print(files)  # 印出讀取到的檔名稱，用來確認自己是不是真的有讀到

n = 0  # 設定初始值
for i in files:  # 因為資料夾裡面的檔案都要重新更換名稱
    oldname = os.path.join(path, files[n])  # 指出檔案現在的路徑名稱，[n]表示第n個檔案
    newname = os.path.join(path, "stapler_img_" + str(n+1) + ".png")  # 新的檔案名稱
    os.rename(oldname, newname)
    print(oldname + " >>> " + newname)
    n = n + 1
    print("done ",n," times")

print("completed!")
