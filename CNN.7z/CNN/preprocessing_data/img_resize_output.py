# data_processing/data_processor.py
import os
import shutil
from PIL import Image
import random
import logging
from tqdm import tqdm

class DataPreprocessor:
    """數據預處理類"""
    def __init__(self, source_dir, target_dir, img_size=(320, 320), train_ratio=1):
        self.source_dir = source_dir
        self.target_dir = target_dir
        self.img_size = img_size
        self.train_ratio = train_ratio
        self.logger = self._setup_logger()

    def _setup_logger(self):
        logger = logging.getLogger('DataPreprocessor')
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def process(self):
        """執行數據預處理"""
        self.logger.info("開始數據預處理...")
        
        # 創建目標目錄結構
        train_dir = os.path.join(self.target_dir, 'train')
        val_dir = os.path.join(self.target_dir, 'val')
        os.makedirs(train_dir, exist_ok=True)
        os.makedirs(val_dir, exist_ok=True)

        # 處理每個類別
        categories = [d for d in os.listdir(self.source_dir) 
                     if os.path.isdir(os.path.join(self.source_dir, d))]
        
        for category in categories:
            self.logger.info(f"處理類別: {category}")
            
            # 創建類別目錄
            os.makedirs(os.path.join(train_dir, category), exist_ok=True)
            os.makedirs(os.path.join(val_dir, category), exist_ok=True)
            
            # 獲取所有圖片
            category_path = os.path.join(self.source_dir, category)
            images = [f for f in os.listdir(category_path) 
                     if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            
            # 隨機打亂並分割
            random.shuffle(images)
            split_idx = int(len(images) * self.train_ratio)
            train_images = images[:split_idx]
            val_images = images[split_idx:]
            
            # 處理訓練集圖片
            self._process_image_set(train_images, category_path, 
                                  os.path.join(train_dir, category))
            
            # 處理驗證集圖片
            self._process_image_set(val_images, category_path, 
                                  os.path.join(val_dir, category))
            
        self.logger.info("數據預處理完成！")

    def _process_image_set(self, image_list, src_dir, dst_dir):
        """處理圖片集合"""
        for img_name in tqdm(image_list, desc="處理圖片"):
            try:
                # 讀取原始圖片
                img_path = os.path.join(src_dir, img_name)
                img = Image.open(img_path)
                
                # 轉換為RGB模式
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # 調整大小
                img = img.resize(self.img_size, Image.Resampling.LANCZOS)
                
                # 保存處理後的圖片
                save_path = os.path.join(dst_dir, img_name)
                img.save(save_path, quality=95)
                
            except Exception as e:
                self.logger.error(f"處理圖片 {img_name} 時發生錯誤: {str(e)}")

def main():
    # 設置路徑
    source_dir = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\enhencement_images_jpg"
    target_dir = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\datasets"
    
    # 創建預處理器並執行
    preprocessor = DataPreprocessor(source_dir, target_dir)
    preprocessor.process()

if __name__ == "__main__":
    main()
