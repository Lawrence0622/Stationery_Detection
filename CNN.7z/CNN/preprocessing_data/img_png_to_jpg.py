import os
from PIL import Image
import shutil
import torch
import torchvision.transforms as transforms
import time
from tqdm import tqdm

def convert_to_jpg(input_folder, output_folder, target_size=(640,640), batch_size=32):
    """
    使用GPU將輸入資料夾中的PNG圖片轉換為JPG格式，並調整為統一大小
    
    參數:
    input_folder: 輸入資料夾路徑
    output_folder: 輸出資料夾路徑
    target_size: 目標圖片大小，預設(640, 640)
    batch_size: 批次處理大小
    """
    # 檢查GPU是否可用
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用設備: {device}")
    
    # 創建輸出資料夾
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    # 獲取所有PNG圖片
    image_files = [f for f in os.listdir(input_folder) 
                  if f.lower().endswith('.png')]
    
    total_files = len(image_files)
    print(f"找到 {total_files} 個PNG檔案")
    
    # 創建轉換器，包含resize
    transform = transforms.Compose([
        transforms.Resize(target_size),
        transforms.ToTensor()
    ])
    to_pil = transforms.ToPILImage()
    
    # 批次處理圖片
    for i in tqdm(range(0, total_files, batch_size)):
        batch_files = image_files[i:min(i + batch_size, total_files)]
        
        try:
            # 處理一個批次
            batch_tensors = []
            for img_file in batch_files:
                # 讀取圖片
                img_path = os.path.join(input_folder, img_file)
                img = Image.open(img_path)
                
                # 處理透明通道
                if img.mode == 'RGBA':
                    bg = Image.new('RGB', img.size, (255, 255, 255))
                    bg.paste(img, mask=img.split()[3])
                    img = bg
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # 轉換為tensor並resize
                tensor = transform(img).to(device)
                batch_tensors.append(tensor)
            
            # 將批次整合為一個tensor
            batch = torch.stack(batch_tensors)
            
            # GPU處理
            with torch.no_grad():
                processed_batch = batch
            
            # 儲存處理後的圖片
            for j, tensor in enumerate(processed_batch):
                # 移回CPU並轉換為PIL圖片
                img = to_pil(tensor.cpu())
                
                # 生成新檔名
                original_filename = batch_files[j]
                jpg_file = os.path.splitext(original_filename)[0] + '.jpg'
                save_path = os.path.join(output_folder, jpg_file)
                
                # 儲存為JPG
                img.save(save_path, 'JPEG', quality=95)
            
            # 清理GPU緩存
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                
        except Exception as e:
            print(f"\n處理批次時發生錯誤: {str(e)}")
            continue
    
    print("\n轉換完成！")
    print(f"輸出資料夾: {output_folder}")

# 使用示例
if __name__ == "__main__":
    # 記錄開始時間
    start_time = time.time()
    
    # 設定路徑
    base_input_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\composition_images_png"
    base_output_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\composition_images_jpg"
    
    # 類別列表
    classes = ['eraser', 'pen', 'glue', 'binder_clip', 'stapler']
    
    # 處理每個類別
    for class_name in classes:
        print(f"\n處理類別: {class_name}")
        print("=" * 50)
        
        input_folder = os.path.join(base_input_folder, class_name)
        output_folder = os.path.join(base_output_folder, class_name)
        
        # 可以根據需要調整目標大小
        convert_to_jpg(input_folder, output_folder, target_size=(640, 640), batch_size=32)
    
    # 計算總處理時間
    end_time = time.time()
    total_time = end_time - start_time
    print(f"\n總處理時間: {total_time:.2f} 秒")