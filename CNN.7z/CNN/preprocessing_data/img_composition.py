import cv2
import torch
import numpy as np
import os
from glob import glob
import random
from torchvision import transforms
from PIL import Image

def get_random_position(background_shape, obj_shape):
    """隨機選擇一個位置（中心、八個方向），位置適度遠離中心"""
    bg_height, bg_width = background_shape[:2]
    obj_height, obj_width = obj_shape[:2]
    
    # 計算中心點
    center_x = (bg_width - obj_width) // 2
    center_y = (bg_height - obj_height) // 2
    
    # 計算可移動的最大距離（從中心點算起）
    max_offset_x = (min(center_x, bg_width - center_x) * 3) // 4
    max_offset_y = (min(center_y, bg_height - center_y) * 3) // 4
    
    # 定義九個位置
    positions = {
        "center": (center_x, center_y),
        "top": (center_x, center_y - max_offset_y),
        "bottom": (center_x, center_y + max_offset_y),
        "left": (center_x - max_offset_x, center_y),
        "right": (center_x + max_offset_x, center_y),
        "top_left": (center_x - max_offset_x, center_y - max_offset_y),
        "top_right": (center_x + max_offset_x, center_y - max_offset_y),
        "bottom_left": (center_x - max_offset_x, center_y + max_offset_y),
        "bottom_right": (center_x + max_offset_x, center_y + max_offset_y)
    }
    
    position_name = random.choice(list(positions.keys()))
    return position_name, positions[position_name]

def load_image_with_alpha(image_path):
    """載入圖片並轉換為 PyTorch tensor"""
    # 使用 PIL 讀取圖片以保持 alpha 通道
    img = Image.open(image_path)
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    
    # 轉換為 tensor
    transform = transforms.ToTensor()
    return transform(img)

def compose_image_torch(background_path, obj_path, position):
    """使用 PyTorch 在指定位置合成圖片"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 讀取背景圖片
    background = cv2.imread(background_path)
    background = cv2.rotate(background, cv2.ROTATE_90_COUNTERCLOCKWISE)
    background = cv2.cvtColor(background, cv2.COLOR_BGR2RGB)
    background = torch.from_numpy(background).permute(2, 0, 1).float() / 255.0
    background = background.to(device)
    
    # 讀取物件圖片（包含 alpha 通道）
    obj = load_image_with_alpha(obj_path).to(device)
    
    # 獲取位置座標
    x, y = position
    
    # 創建結果張量
    result = background.clone()
    
    # 獲取物件的尺寸
    _, obj_height, obj_width = obj.shape
    
    # 計算有效的合成區域
    valid_height = min(obj_height, result.shape[1] - y)
    valid_width = min(obj_width, result.shape[2] - x)
    
    # 提取 alpha 通道
    alpha = obj[3, :valid_height, :valid_width].unsqueeze(0)
    
    # 使用 alpha blending 合成圖片
    obj_rgb = obj[:3, :valid_height, :valid_width]
    background_patch = result[:, y:y+valid_height, x:x+valid_width]
    
    # 應用 alpha blending
    result[:, y:y+valid_height, x:x+valid_width] = (
        obj_rgb * alpha + background_patch * (1 - alpha)
    )
    
    # 轉換回 CPU 並轉為 numpy array
    result = (result.cpu().numpy() * 255).astype(np.uint8)
    result = np.transpose(result, (1, 2, 0))
    
    # 轉換回 BGR 顏色空間
    result = cv2.cvtColor(result, cv2.COLOR_RGB2BGR)
    
    return result

def process_dataset(background_folder, obj_folder, output_folder):
    """批次處理資料集"""
    # 檢查 GPU 是否可用
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 確保輸出資料夾存在
    os.makedirs(output_folder, exist_ok=True)
    
    # 獲取所有圖片路徑
    background_paths = glob(os.path.join(background_folder, '*.png'))
    background_paths.extend(glob(os.path.join(background_folder, '*.jpg')))
    background_paths.sort()
    
    obj_paths = glob(os.path.join(obj_folder, '*.png'))
    obj_paths.sort()
    
    output_count = 0
    
    # 處理每張背景圖片
    for bg_idx, background_path in enumerate(background_paths, 1):
        print(f"\nProcessing background {bg_idx}/{len(background_paths)}: {background_path}")
        
        # 讀取背景圖片以獲取尺寸
        bg_temp = cv2.imread(background_path)
        bg_temp = cv2.rotate(bg_temp, cv2.ROTATE_90_COUNTERCLOCKWISE)
        
        # 處理每張去背圖片
        for obj_idx, obj_path in enumerate(obj_paths, 1):
            output_count += 1
            print(f"  Processing object {obj_idx}/{len(obj_paths)}: {obj_path}")
            
            # 讀取物件圖片以獲取尺寸
            obj_temp = Image.open(obj_path)
            
            # 隨機獲取一個合成位置
            pos_name, position = get_random_position(bg_temp.shape, obj_temp.size[::-1])
            
            # 合成圖片
            result = compose_image_torch(background_path, obj_path, position)
            
            # 生成輸出文件名
            output_filename = f"binder_clip_composed_{output_count:04d}_{pos_name}.png"
            output_path = os.path.join(output_folder, output_filename)
            
            # 儲存結果
            cv2.imwrite(output_path, result)
            print(f"    Saved to {output_path} (Position: {pos_name})")

if __name__ == "__main__":
    # 設定路徑
    background_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\background_images_png"
    obj_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\background_removed_images_png\stapler"
    output_folder = r"C:\113-1\Project_Design_of_Deep_Learning\final_project\data_processing\val_datasets\composition_images_png\stapler"
    
    # 設定隨機種子以確保結果可重現
    random.seed(42)
    torch.manual_seed(42)
    
    # 執行批次處理
    process_dataset(background_folder, obj_folder, output_folder)