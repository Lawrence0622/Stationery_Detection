import os
import torch
import torch.nn as nn
import torch.optim as optim
from datetime import datetime, timedelta
import logging
import platform
import time
import argparse
from tqdm import tqdm
from typing import Dict, Any, Optional

# 檢查必要的套件
try:
    import seaborn as sns
    from sklearn.metrics import confusion_matrix
except ImportError:
    print("請安裝必要的套件：pip install seaborn scikit-learn")
    exit(1)

from datasets.dataset import get_dataloaders
from utils.metrics import MetricsTracker
from models.model_architecture import create_model

def parse_args():
    parser = argparse.ArgumentParser(description='Train image classification model')
    parser.add_argument('--data_dir', type=str, default='datasets',
                      help='Directory containing the processed dataset')
    parser.add_argument('--batch_size', type=int, default=32,
                      help='Batch size for training')
    parser.add_argument('--epochs', type=int, default=100,
                      help='Number of epochs to train')
    parser.add_argument('--lr', type=float, default=0.001,
                      help='Learning rate')
    parser.add_argument('--l2_lambda', type=float, default=0.01,
                      help='L2 regularization coefficient')
    parser.add_argument('--patience', type=int, default=20,
                      help='Patience for early stopping')
    parser.add_argument('--num_workers', type=int, default=4,
                      help='Number of workers for data loading')
    parser.add_argument('--device', type=str, default='cuda',
                      choices=['cuda', 'cpu'],
                      help='Device to use for training')
    parser.add_argument('--scheduler_factor', type=float, default=0.5,
                      help='Factor by which to reduce learning rate')
    parser.add_argument('--scheduler_patience', type=int, default=10,
                      help='Patience epochs for learning rate scheduler')
    return parser.parse_args()

def setup_logger(save_dir):
    logger = logging.getLogger('Training')
    logger.setLevel(logging.INFO)
    
    if logger.handlers:
        logger.handlers.clear()
    
    # 檔案處理器
    fh = logging.FileHandler(os.path.join(save_dir, 'training.log'))
    fh.setLevel(logging.INFO)
    
    # 控制台處理器
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    
    logger.addHandler(fh)
    logger.addHandler(ch)
    
    return logger

def save_checkpoint(state: Dict[str, Any], is_best: bool, 
                   save_dir: str, filename: str = 'checkpoint.pth'):
    """保存檢查點"""
    os.makedirs(save_dir, exist_ok=True)
    checkpoint_file = os.path.join(save_dir, filename)
    torch.save(state, checkpoint_file)
    
    if is_best:
        best_file = os.path.join(save_dir, 'best_model.pth')
        torch.save(state, best_file)

def load_checkpoint(checkpoint_path: str, model: torch.nn.Module, 
                   optimizer: Optional[torch.optim.Optimizer] = None, 
                   scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None) -> Dict[str, Any]:
    """加載檢查點"""
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"找不到檢查點文件：{checkpoint_path}")
    
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    if optimizer is not None and 'optimizer_state_dict' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    if scheduler is not None and 'scheduler_state_dict' in checkpoint:
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
    
    return checkpoint

def get_model_info(model: torch.nn.Module) -> Dict[str, Any]:
    """獲取模型信息"""
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    return {
        'total_parameters': total_params,
        'trainable_parameters': trainable_params,
        'model_structure': str(model)
    }

def train_epoch(model, train_loader, criterion, optimizer, device):
    """訓練一個 epoch"""
    model.train()
    total_loss = 0
    total_base_loss = 0
    total_l2_loss = 0
    correct = 0
    total = 0
    
    pbar = tqdm(train_loader, desc='Training')
    for inputs, targets in pbar:
        inputs, targets = inputs.to(device), targets.to(device)
        
        optimizer.zero_grad()
        outputs = model(inputs)
        
        # 計算基礎損失和L2正則化損失
        base_loss = criterion(outputs, targets)
        l2_loss = model.l2_regularization()
        loss = base_loss + l2_loss
        
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        total_base_loss += base_loss.item()
        total_l2_loss += l2_loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
        
        pbar.set_postfix({
            'loss': f'{loss.item():.4f}',
            'base_loss': f'{base_loss.item():.4f}',
            'l2_loss': f'{l2_loss.item():.4f}',
            'acc': f'{100.*correct/total:.2f}%'
        })
    
    metrics = {
        'loss': total_loss / len(train_loader),
        'accuracy': 100. * correct / total,
        'base_loss': total_base_loss / len(train_loader),
        'l2_loss': total_l2_loss / len(train_loader)
    }
    
    return metrics

def validate(model, val_loader, criterion, device):
    """驗證模型"""
    model.eval()
    total_loss = 0
    total_base_loss = 0
    total_l2_loss = 0
    correct = 0
    total = 0
    
    with torch.no_grad():
        pbar = tqdm(val_loader, desc='Validation')
        for inputs, targets in pbar:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            
            base_loss = criterion(outputs, targets)
            l2_loss = model.l2_regularization()
            loss = base_loss + l2_loss
            
            total_loss += loss.item()
            total_base_loss += base_loss.item()
            total_l2_loss += l2_loss.item()
            
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
            
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'acc': f'{100.*correct/total:.2f}%'
            })
    
    metrics = {
        'loss': total_loss / len(val_loader),
        'accuracy': 100. * correct / total,
        'base_loss': total_base_loss / len(val_loader),
        'l2_loss': total_l2_loss / len(val_loader)
    }
    
    return metrics

def main():
    args = parse_args()
    
    # 檢查CUDA可用性
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA不可用，切換到CPU")
        args.device = 'cpu'
    
    # 檢查數據目錄
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, args.data_dir.lstrip('./'))
    train_dir = os.path.join(data_dir, 'train')
    val_dir = os.path.join(data_dir, 'val')
    
    if not os.path.exists(data_dir):
        raise FileNotFoundError(f"找不到數據目錄：{data_dir}")
    if not os.path.exists(train_dir) or not os.path.exists(val_dir):
        raise FileNotFoundError(f"訓練或驗證數據目錄不存在: {train_dir}, {val_dir}")
    
    # 設置保存目錄
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    save_dir = os.path.join(base_dir, 'results', f'experiment_{timestamp}')
    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(os.path.join(save_dir, 'checkpoints'), exist_ok=True)
    
    # 設置日誌
    logger = setup_logger(save_dir)
    logger.info("Training configuration:")
    for arg in vars(args):
        logger.info(f"  {arg}: {getattr(args, arg)}")
    
    try:
        # 準備數據
        train_loader, val_loader = get_dataloaders(
            data_dir,
            batch_size=args.batch_size,
            num_workers=args.num_workers
        )
        
        # 創建模型
        num_classes = len(os.listdir(train_dir))
        device = torch.device(args.device)
        model = create_model(num_classes).to(device)
        model.l2_lambda = args.l2_lambda  # 設置L2正則化係數
        
        # 記錄模型信息
        model_info = get_model_info(model)
        logger.info(f"模型總參數量: {model_info['total_parameters']:,}")
        logger.info(f"可訓練參數量: {model_info['trainable_parameters']:,}")
        logger.info(f"Number of classes: {num_classes}")
        logger.info(f"Using device: {device}")
        
        # 設置訓練
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=args.lr)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='max',
            factor=args.scheduler_factor,
            patience=args.scheduler_patience,
            verbose=True
        )
        
        # 創建指標追蹤器
        metrics_tracker = MetricsTracker(save_dir)
        
        # 訓練循環
        best_val_acc = 0
        patience_counter = 0
        start_time = datetime.now()
        
        logger.info(f"Starting training at {start_time}")
        
        for epoch in range(args.epochs):
            logger.info(f'\nEpoch {epoch+1}/{args.epochs}')
            epoch_start_time = time.time()
            
            # 訓練和驗證
            train_metrics = train_epoch(model, train_loader, criterion, optimizer, device)
            val_metrics = validate(model, val_loader, criterion, device)
            
            epoch_time = time.time() - epoch_start_time
            current_lr = optimizer.param_groups[0]['lr']
            
            # 更新學習率
            scheduler.step(val_metrics['accuracy'])
            
            # 計算已用時間和預估剩餘時間
            elapsed_time = datetime.now() - start_time
            remaining_epochs = args.epochs - epoch - 1
            estimated_time = (elapsed_time / (epoch + 1)) * remaining_epochs if epoch > 0 else timedelta(0)
            
            # 記錄訓練信息
            logger.info(
                f"Train Loss: {train_metrics['loss']:.4f} "
                f"(Base: {train_metrics['base_loss']:.4f}, "
                f"L2: {train_metrics['l2_loss']:.4f}), "
                f"Train Acc: {train_metrics['accuracy']:.2f}%"
            )
            logger.info(
                f"Val Loss: {val_metrics['loss']:.4f} "
                f"(Base: {val_metrics['base_loss']:.4f}, "
                f"L2: {val_metrics['l2_loss']:.4f}), "
                f"Val Acc: {val_metrics['accuracy']:.2f}%"
            )
            logger.info(f"Learning Rate: {current_lr:.6f}")
            logger.info(f"Time: {epoch_time:.2f}s (Elapsed: {elapsed_time}, Remaining: {estimated_time})")
            
            # 更新指標追蹤器和保存檢查點
            is_best = metrics_tracker.update(train_metrics, val_metrics, current_lr, epoch_time)
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'train_metrics': train_metrics,
                'val_metrics': val_metrics,
            }
            save_checkpoint(checkpoint, is_best, os.path.join(save_dir, 'checkpoints'))
            
            if is_best:
                best_val_acc = val_metrics['accuracy']
                patience_counter = 0
                logger.info(f"New best model saved! Validation Accuracy: {best_val_acc:.2f}%")
            else:
                patience_counter += 1
            
            if patience_counter >= args.patience:
                logger.info(f"Early stopping triggered after epoch {epoch+1}")
                break
        
        # 訓練完成後生成混淆矩陣
        logger.info("Generating confusion matrix using best model...")
        best_model_path = os.path.join(save_dir, 'checkpoints', 'best_model.pth')
        if os.path.exists(best_model_path):
            load_checkpoint(best_model_path, model)
            cm, class_accuracies = metrics_tracker.plot_confusion_matrix(model, val_loader, device)
            
            logger.info("\nPer-class accuracies:")
            for i, acc in enumerate(class_accuracies):
                logger.info(f"Class {i}: {acc:.2%}")
        
        # 保存最終的訓練指標和圖表
        end_time = datetime.now()
        training_time = end_time - start_time
        logger.info(f"Training completed in {training_time}")
        
        config = vars(args)
        metrics_tracker.save_metrics(config)
        metrics_tracker.plot_metrics()
        
        logger.info(f"Training completed. Best validation accuracy: {best_val_acc:.2f}%")

    except Exception as e:
        logger.error(f"訓練過程中發生錯誤: {str(e)}")
        raise e

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('訓練已中斷')
    except Exception as e:
        print(f'發生錯誤: {str(e)}')