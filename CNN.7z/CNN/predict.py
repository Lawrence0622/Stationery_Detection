import os
import torch
import argparse
from PIL import Image
import torchvision.transforms as transforms
from models.model_architecture import create_model
from tqdm import tqdm
import json
from datetime import datetime
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

def parse_args():
    parser = argparse.ArgumentParser(description='Evaluate model performance')
    parser.add_argument('--model_path', type=str, required=True,
                      help='Path to the trained model checkpoint')
    parser.add_argument('--test_dir', type=str, required=True,
                      help='Directory containing test images in class folders')
    parser.add_argument('--output_dir', type=str, default='evaluation_results',
                      help='Directory to save evaluation results')
    parser.add_argument('--device', type=str, default='cuda',
                      choices=['cuda', 'cpu'],
                      help='Device to use for evaluation')
    return parser.parse_args()

def get_transforms():
    """獲取與訓練時相同的數據轉換"""
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])

def load_model(model_path, num_classes, device):
    """載入訓練好的模型"""
    model = create_model(num_classes)
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()
    return model

def plot_confusion_matrix(conf_matrix, class_names, output_path):
    """繪製混淆矩陣"""
    plt.figure(figsize=(10, 8))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names, yticklabels=class_names)
    plt.title('Confusion Matrix')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def evaluate_model(model, test_dir, transform, device, output_dir):
    """評估模型性能"""
    # 獲取類別列表
    class_names = sorted(os.listdir(test_dir))
    class_to_idx = {cls_name: i for i, cls_name in enumerate(class_names)}
    
    all_predictions = []
    all_labels = []
    prediction_details = {}
    
    # 遍歷每個類別目錄
    for class_name in class_names:
        class_dir = os.path.join(test_dir, class_name)
        if not os.path.isdir(class_dir):
            continue
            
        # 遍歷該類別下的所有圖片
        for img_name in tqdm(os.listdir(class_dir), desc=f'Evaluating {class_name}'):
            if not img_name.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                continue
                
            img_path = os.path.join(class_dir, img_name)
            try:
                # 讀取和預處理圖片
                image = Image.open(img_path).convert('RGB')
                image_tensor = transform(image).unsqueeze(0).to(device)
                
                # 進行預測
                with torch.no_grad():
                    outputs = model(image_tensor)
                    probabilities = torch.nn.functional.softmax(outputs, dim=1)
                    top3_prob, top3_indices = torch.topk(probabilities, 3)
                    
                    # 獲取預測結果
                    predicted_class = top3_indices[0][0].item()
                    
                # 記錄預測細節
                prediction_details[img_path] = {
                    'true_class': class_name,
                    'predicted_class': class_names[predicted_class],
                    'correct': class_name == class_names[predicted_class],
                    'top3_predictions': [
                        {
                            'class': class_names[idx.item()],
                            'probability': prob.item()
                        }
                        for prob, idx in zip(top3_prob[0], top3_indices[0])
                    ]
                }
                
                # 記錄預測結果用於計算指標
                all_predictions.append(predicted_class)
                all_labels.append(class_to_idx[class_name])
                
            except Exception as e:
                print(f"Error processing {img_path}: {str(e)}")
    
    # 計算混淆矩陣
    conf_matrix = confusion_matrix(all_labels, all_predictions)
    
    # 計算分類報告
    report = classification_report(all_labels, all_predictions,
                                 target_names=class_names,
                                 output_dict=True)
    
    # 保存結果
    results = {
        'classification_report': report,
        'confusion_matrix': conf_matrix.tolist(),
        'prediction_details': prediction_details
    }
    
    # 繪製並保存混淆矩陣圖
    plot_confusion_matrix(conf_matrix, class_names,
                         os.path.join(output_dir, 'confusion_matrix.png'))
    
    return results, class_names

def main():
    args = parse_args()
    
    # 設置保存目錄
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = os.path.join(args.output_dir, f'evaluation_{timestamp}')
    os.makedirs(output_dir, exist_ok=True)
    
    # 設置設備
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 獲取類別數量
    num_classes = len([d for d in os.listdir(args.test_dir) 
                      if os.path.isdir(os.path.join(args.test_dir, d))])
    
    # 載入模型
    print("Loading model...")
    model = load_model(args.model_path, num_classes, device)
    
    # 準備數據轉換
    transform = get_transforms()
    
    # 評估模型
    print("Starting evaluation...")
    results, class_names = evaluate_model(model, args.test_dir, transform,
                                        device, output_dir)
    
    # 保存詳細結果
    with open(os.path.join(output_dir, 'evaluation_results.json'), 'w',
              encoding='utf-8') as f:
        json.dump(results, f, indent=4, ensure_ascii=False)
    
    # 打印總體準確率
    overall_accuracy = results['classification_report']['accuracy'] * 100
    print("\nEvaluation Results:")
    print(f"Overall Accuracy: {overall_accuracy:.2f}%")
    print("\nPer-class Performance:")
    for class_name in class_names:
        metrics = results['classification_report'][class_name]
        print(f"\n{class_name}:")
        print(f"  Precision: {metrics['precision']*100:.2f}%")
        print(f"  Recall: {metrics['recall']*100:.2f}%")
        print(f"  F1-Score: {metrics['f1-score']*100:.2f}%")
    
    print(f"\nDetailed results saved to: {output_dir}")
    print("- evaluation_results.json: Contains detailed predictions and metrics")
    print("- confusion_matrix.png: Visual representation of model predictions")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nEvaluation interrupted by user')
    except Exception as e:
        print(f'Error occurred: {str(e)}')
