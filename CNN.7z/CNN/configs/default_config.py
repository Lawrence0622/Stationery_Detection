# configs/default_config.py
from dataclasses import dataclass, field
from typing import List, Dict, Any
import os

@dataclass
class ModelConfig:
    """模型相關配置"""
    # 基本架構配置
    input_size: tuple = (320, 320)
    channels: List[int] = field(default_factory=lambda: [64, 128, 256, 512])
    num_blocks: List[int] = field(default_factory=lambda: [2, 2, 2, 2])
    dropout_rates: List[float] = field(default_factory=lambda: [0.2, 0.3, 0.4, 0.5])
    
    # 全連接層配置
    fc_features: List[int] = field(default_factory=lambda: [512, 256])
    fc_dropout: float = 0.5

@dataclass
class TrainingConfig:
    """訓練相關配置"""
    batch_size: int = 32
    epochs: int = 100
    learning_rate: float = 0.001
    weight_decay: float = 1e-4
    
    # 學習率調度器配置
    scheduler_patience: int = 7
    scheduler_factor: float = 0.1
    scheduler_threshold: float = 0.005
    min_lr: float = 1e-6
    
    # 早停配置
    early_stopping_patience: int = 15
    early_stopping_min_delta: float = 0.001

@dataclass
class DataConfig:
    """數據相關配置"""
    data_dir: str = './datasets'
    train_ratio: float = 0.8
    num_workers: int = 4
    
    # 數據增強配置
    use_augmentation: bool = True
    rotation_range: int = 15
    brightness_range: float = 0.2
    contrast_range: float = 0.2
    saturation_range: float = 0.2
    
    # 標準化配置
    normalize_mean: List[float] = field(default_factory=lambda: [0.485, 0.456, 0.406])
    normalize_std: List[float] = field(default_factory=lambda: [0.229, 0.224, 0.225])

@dataclass
class Config:
    """總配置類"""
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    data: DataConfig = field(default_factory=DataConfig)
    device: str = 'cuda'
    experiment_name: str = 'default_experiment'
    save_dir: str = './results'
    
    def __post_init__(self):
        """初始化後的處理"""
        # 更新保存路徑
        self.save_dir = os.path.join(self.save_dir, self.experiment_name)
        os.makedirs(self.save_dir, exist_ok=True)
        os.makedirs(os.path.join(self.save_dir, 'checkpoints'), exist_ok=True)

def get_config() -> Config:
    """獲取默認配置"""
    return Config()
